<?
$link=mysql_connect("localhost", "jonyz", "jonyzjc2");
mysql_select_db("app_music",$link) OR DIE ("Error: No es posible establecer la conexión");
?>